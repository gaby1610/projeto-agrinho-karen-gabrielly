function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}// Variáveis para controlar a "nuvem" e a "chuva"
let nuvemX;
let nuvemY;
let gotas = []; // Um array para armazenar as gotas de chuva

// Variáveis para o carro
let carroX;
let carroY;
let carroVelocidade = 2;

// Variável para a pessoa
let pessoaX;
let pessoaY;

// Array para as plantas
let plantas = [];
let numPlantas = 5; // Quantidade de plantas

function setup() {
  createCanvas(800, 500); // Aumentei um pouco o canvas para caber mais elementos
  nuvemX = width / 2;
  nuvemY = 80;

  carroX = -50; // Começa o carro fora da tela, à esquerda
  carroY = height - 80; // Posiciona o carro no chão

  pessoaX = width / 4; // Posição inicial da pessoa
  pessoaY = height - 70; // Posiciona a pessoa no chão

  // Inicializa as plantas em posições aleatórias no "chão"
  for (let i = 0; i < numPlantas; i++) {
    plantas.push({
      x: random(50, width - 50),
      y: height - 60,
      altura: random(20, 40),
      cor: color(0, random(100, 200), 0) // Tons de verde
    });
  }
}

function draw() {
  background(135, 206, 235); // Cor de fundo azul claro (céu)

  // Desenha o "chão" ou "terra"
  fill(34, 139, 34); // Verde escuro
  rect(0, height - 70, width, 70); // Aumentei a altura do chão

  // --- Desenha as plantas ---
  for (let i = 0; i < plantas.length; i++) {
    let p = plantas[i];
    fill(p.cor);
    // Tronco da planta
    rect(p.x, p.y, 5, -p.altura);
    // Folhas da planta
    ellipse(p.x + 2, p.y - p.altura - 5, 15, 10);
    ellipse(p.x - 5, p.y - p.altura, 15, 10);
  }

  // Desenha a "nuvem"
  fill(255, 255, 255, 200); // Branco com um pouco de transparência
  ellipse(nuvemX, nuvemY, 150, 70);
  ellipse(nuvemX - 40, nuvemY + 20, 80, 50);
  ellipse(nuvemX + 40, nuvemY + 20, 80, 50);

  // Faz a nuvem se mover um pouco
  nuvemX += random(-0.5, 0.5); // Movimento horizontal leve
  nuvemX = constrain(nuvemX, 100, width - 100); // Mantém a nuvem na tela

  // Faz chover!
  if (frameCount % 10 == 0) { // A cada 10 frames, cria uma nova gota
    let gota = {
      x: random(nuvemX - 50, nuvemX + 50),
      y: nuvemY + 30,
      velocidade: random(3, 8)
    };
    gotas.push(gota);
  }

  // Atualiza e desenha as gotas
  for (let i = gotas.length - 1; i >= 0; i--) {
    let g = gotas[i];
    g.y += g.velocidade; // A gota cai

    // Desenha a gota
    stroke(0, 0, 255); // Azul escuro
    line(g.x, g.y, g.x, g.y + 10);

    // Remove a gota se ela saiu da tela (caiu no "chão")
    if (g.y > height - 70) { // Ajustei para a nova altura do chão
      gotas.splice(i, 1);
    }
  }

  // --- Desenha o carro ---
  fill(255, 0, 0); // Vermelho para o corpo do carro
  rect(carroX, carroY, 80, 30); // Corpo do carro
  fill(0); // Preto para as rodas
  ellipse(carroX + 20, carroY + 30, 20, 20); // Roda dianteira
  ellipse(carroX + 60, carroY + 30, 20, 20); // Roda traseira

  // Move o carro
  carroX += carroVelocidade;
  // Reinicia o carro se ele sair da tela
  if (carroX > width) {
    carroX = -80; // Volta para o lado esquerdo
  }

  // --- Desenha a pessoa ---
  fill(255, 200, 150); // Cor de pele
  ellipse(pessoaX, pessoaY - 40, 20, 20); // Cabeça
  fill(0, 0, 150); // Cor da roupa (azul)
  rect(pessoaX - 10, pessoaY - 30, 20, 40); // Corpo
  // Pernas
  rect(pessoaX - 8, pessoaY + 10, 5, 15);
  rect(pessoaX + 3, pessoaY + 10, 5, 15);
  // Braços
  rect(pessoaX - 15, pessoaY - 20, 10, 5);
  rect(pessoaX + 5, pessoaY - 20, 10, 5);

  // Adiciona um título simples
  fill(0); // Preto
  textSize(28);
  textAlign(CENTER, TOP);
  text("Ciclo da Água na Cidade", width / 2, 20);
}

// Interatividade: Clique para o carro ir mais rápido (exemplo)
function mousePressed() {
  carroVelocidade = random(3, 7); // Altera a velocidade do carro
}